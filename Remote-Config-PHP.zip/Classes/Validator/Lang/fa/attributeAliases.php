<?php
return [
    "name" => "نام",
    "email" => "ایمیل",
    "password" => "رمز عبور",
    "username" => "نام کاربری",
    "phone" => "شماره تلفن",
    "phone_number" => "شماره تلفن",
    "confirm_password" => "تایید رمز عبور",
    "date" => "تاریخ",
    "avatar" => "آواتار",
    "user_email" => "ایمیل",
];