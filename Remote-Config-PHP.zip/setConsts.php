<?php
const BASE_DIR = __DIR__;

// TODO: full fix titles