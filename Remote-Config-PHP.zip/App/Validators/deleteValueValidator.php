<?php


return [
    "value_id" => ['required', 'numeric'],
];
