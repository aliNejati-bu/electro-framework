<?php

namespace MazaresServices\App\Controller;

class ExampleController
{
    public function getIndex(): string
    {
        return "index";
    }
}