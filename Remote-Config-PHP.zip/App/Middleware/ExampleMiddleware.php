<?php

namespace MazaresServices\App\Middleware;

use MazaresServices\Boot\Interfaces\MiddlewareInterface;

class ExampleMiddleware implements MiddlewareInterface
{

    /**
     * @return mixed|void|null
     */
    public function run()
    {

    }
}