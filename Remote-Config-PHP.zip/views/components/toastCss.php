<!-- Jquery Toast css -->
<link href="/assets/libs/jquery-toast/jquery.toast.min.css" rel="stylesheet" type="text/css"/>
<?php
echo "<style> </style>";
?>