<footer>
    <div class="footer-area">
        <p>© Copyright 2021. All right reserved For Mazares Services. Powered by <a href="https://www.linkedin.com/in/alinejati-bu/">Ali Nejati</a>.</p>
    </div>
</footer><?php
echo "<span> </span>";
?>