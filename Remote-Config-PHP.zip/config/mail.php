<?php


return [
    "SMTPSecure" => "tls",
    "SMTPPort" => 587,
    "SMTPHost" => "smtp.gmail.com",
    "SMTPUserName" => "4MazaresServicesweb@gmail.com",
    "SMTPPassword" => "Xq$`[)j9~+QqgvDX#XLj{8wn~4u`L::r",
];