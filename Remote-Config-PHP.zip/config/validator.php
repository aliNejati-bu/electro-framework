<?php

return [
    'validators_path' => BASE_DIR.DIRECTORY_SEPARATOR."App".DIRECTORY_SEPARATOR."Validators"
];