<?php

return [
    'cid' => "217585187363-oqqm8m7k973afg49jfnjgnh12muhqmb3.apps.googleusercontent.com",
    'cs' => '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',
    'rdu' => '/login-with-google'
];