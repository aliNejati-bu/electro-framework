<?php

return [
    "server" => "localhost",
    "username" => "root",
    "password" => "",
    "dbname" => "remote_config"
];